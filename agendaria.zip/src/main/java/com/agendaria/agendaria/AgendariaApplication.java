package com.agendaria.agendaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgendariaApplication {

    public static void main(String[] args) {
        SpringApplication.run(AgendariaApplication.class, args);
    }
}
