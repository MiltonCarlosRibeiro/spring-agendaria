package com.agendaria.agendaria.domain.enums;

public enum AppointmentStatus {
    BOOKED,
    CANCELLED,
    NO_SHOW,
    COMPLETED
}
