package com.agendaria.agendaria.web.dto;

import lombok.Data;

@Data
public class CancelRescheduleDto {
    private String reason;
}
