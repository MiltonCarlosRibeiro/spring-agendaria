package com.agendaria.agendaria.web.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AppointmentResponseDto {
    private Long id;
    private String customerName;
    private String procedureName;
    private String startDateTime;
    private String endDateTime;
    private String status;
}
