package com.agendaria.agendaria.web.dto;

import lombok.Data;

@Data
public class ChatAskDto {
    private String message;
}
